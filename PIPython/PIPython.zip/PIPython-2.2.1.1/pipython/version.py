#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.2.1.1'
__signature__ = 0x94b26a5c084b2bfacfe35de0f7f1b3b0
