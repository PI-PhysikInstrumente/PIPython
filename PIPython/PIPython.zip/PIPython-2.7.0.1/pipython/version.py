#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.7.0.1'
__signature__ = 0xe8d71795fbdc71b949746684c84b37e4
