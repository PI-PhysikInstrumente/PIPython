#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.6.0.1'
__signature__ = 0x2df85b9fee97da453e95ee11bc3fc7cd
