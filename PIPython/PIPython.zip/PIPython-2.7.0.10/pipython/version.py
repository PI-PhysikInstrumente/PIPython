#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.7.0.10'
__signature__ = 0xe487c5b015b96b71d411eac90809deb
