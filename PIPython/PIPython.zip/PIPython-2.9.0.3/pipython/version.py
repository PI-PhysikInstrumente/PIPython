#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.9.0.3'
__signature__ = 0x67b160e48b70b9551b8b866014b6be88
