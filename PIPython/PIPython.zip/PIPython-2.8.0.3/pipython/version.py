#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.8.0.3'
__signature__ = 0x7cb4bcf9f49c7bc5e2ebc34d7ac987a8
