#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.7.0.5'
__signature__ = 0x8e7065109f30e4988d16e73b7e7963dd
