#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.4.0.1'
__signature__ = 0x5ad1ecc23ddc0e62e1860b091ce09c3d
