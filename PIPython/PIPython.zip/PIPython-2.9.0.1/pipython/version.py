#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.9.0.1'
__signature__ = 0x84748d6d3eecf4264b8a2f91de1ad769
