#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.7.0.2'
__signature__ = 0xc3f76ea0c531c8f18b538b31584ccab4
