#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.5.0.1'
__signature__ = 0x496f78f44d1c1c9667c53ae0980d49c3
