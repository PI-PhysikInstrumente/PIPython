#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.2.2.1'
__signature__ = 0xdb49bbcf6c6ae17f7d5ed931ef027c90
