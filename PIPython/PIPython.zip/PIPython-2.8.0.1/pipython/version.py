#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.8.0.1'
__signature__ = 0x2153a1d05a506e058303cd4b9046ec3f
