#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.10.1.1'
__signature__ = 0x88962e3a0707c4618a52fcf905ea4817
