#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.4.0.2'
__signature__ = 0xdb6f391de4059f2175fb359981f0c1b7
