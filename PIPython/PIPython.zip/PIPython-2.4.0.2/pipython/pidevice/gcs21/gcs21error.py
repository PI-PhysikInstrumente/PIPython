#!/usr/bin python
# -*- coding: utf-8 -*-
"""Provide GCSError defines and GCSError exception class."""
# too many lines in module pylint: disable=C0302
# line too long pylint: disable=C0301

from logging import debug
import json
import os

from ..pierror_base import PIErrorBase

__signature__ = 0x5f1219b433fa55569eb775ed0b0c2cc4

# /*!
#  * \brief Structure of an UMF error.
#  * \- RSD:   		Reserved bit
#  * \- FGroup ID: 	Functional Group ID
#  * \- Error Class:  Config or Processing error
#  * \- Error Code:   The error code
#  *  _______________________________________________________________________________________________________________________________
#  * |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |
#  * |             Reserve           |                  FunctionGroup                |   ErrClass    |           ErrorID             |
#  * |___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|
#  *
#  */

# error definition begin  ## DO NOT MODIFY THIS LINE!!!
E0_PI_ERROR_NO_ERROR = 0
E12550_PI_ERROR_MACRO_RUNNING = 12550
E12564_PI_ERROR_MACRO_ALREADY_DEFINED = 12564
E8705_PI_ERROR_CMD_SYNTAX = 8705
E8706_PI_ERROR_CMD_UNKNOWN = 8706
E8714_PI_ERROR_CMD_UCL_INVALID_PWD = 8714
E8715_PI_ERROR_CMD_NOT_ACCESSIBLE = 8715
E12810_PI_ERROR_MACRO_INVALID_NAME = 12810
E12811_PI_ERROR_MACRO_INVALID_OPERATOR = 12811
E12840_PI_ERROR_MACRO_OUT_OF_RANGE = 12840
E12860_PI_ERROR_MACRO_NO_RECORDING = 12860
E13060_PI_ERROR_MACRO_NO_ANSWER = 13060
E13106_PI_ERROR_MACRO_DELETE_ERROR = 13106
E13342_PI_ERROR_MACRO_OUT_OF_MEMORY = 13342
E16642_PI_ERROR_PARAM_NOT_DEFINED = 16642
E16650_PI_ERROR_PARAM_READ_ONLY = 16650
E20747_PI_ERROR_MOTION_REF_MODE_IS_ON = 20747
E20836_PI_ERROR_MOTION_POS_BASED_ON_ESTIMATION = 20836
E20837_PI_ERROR_MOTION_POS_BASED_ON_INTERPOLATION = 20837
E16897_PI_ERROR_PARAM_WRONG_TYPE = 16897
E16901_PI_ERROR_PARAM_PROTECTION = 16901
E16906_PI_ERROR_PARAM_INVALID_SERVO_STATE = 16906
E16907_PI_ERROR_PARAM_NOT_ACCESSIBLE = 16907
E16908_PI_ERROR_PARAM_INVALID_VALUE = 16908
E21004_PI_ERROR_MOTION_CMD_NOT_ALLOWED = 21004
E21005_PI_ERROR_MOTION_INVALID_MODE_OF_OPERATION = 21005
E21006_PI_ERROR_MOTION_AXIS_NOT_CONFIGURED = 21006
E21007_PI_ERROR_MOTION_SMO_WITH_SERVO_ON = 21007
E21008_PI_ERROR_MOTION_DYNAMIC_MOVE_IN_PROCESS = 21008
E21009_PI_ERROR_MOTION_OPEN_LOOP_SET_WHEN_SERVO_ON = 21009
E16936_PI_ERROR_PARAM_OUT_OF_RANGE = 16936
E16937_PI_ERROR_PARAM_INDEX_OUT_OF_RANGE = 16937
E21034_PI_ERROR_MOTION_POS_OUT_OF_LIMITS = 21034
E21035_PI_ERROR_MOTION_VEL_OUT_OF_LIMITS = 21035
E21052_PI_ERROR_MOTION_MOTOR_IS_OFF = 21052
E21053_PI_ERROR_MOTION_SERVO_IS_OFF = 21053
E21054_PI_ERROR_MOTION_AXIS_HAS_NO_BRAKE = 21054
E21055_PI_ERROR_MOTION_REF_WITH_REF_DISABLED = 21055
E21056_PI_ERROR_MOTION_AXIS_HAS_NO_REFERENCE = 21056
E21255_PI_ERROR_MOTION_MAX_MOTOR_OUTPUT_REACHED = 21255
E21348_PI_ERROR_MOTION_POSITION_ERROR_TOO_HIGH = 21348
E21350_PI_ERROR_MOTION_SERVO_LOOP_UNSTABLE = 21350
E21351_PI_ERROR_MOTION_ON_LIMIT_SWITCH = 21351
E21534_PI_ERROR_MOTION_INTERPOLATION_FIFO_OVERFLOW = 21534
E21554_PI_ERROR_MOTION_REFERENCING_FAILED = 21554
E21555_PI_ERROR_MOTION_POSITION_UNKNOWN = 21555
E21604_PI_ERROR_MOTION_COLLISION = 21604
E21605_PI_ERROR_MOTION_MOVE_TO_LIMIT_SWITCH_FAILED = 21605
E21606_PI_ERROR_MOTION_INTERPOLATION_FIFO_UNDERRUN = 21606
E21860_PI_ERROR_MOTION_FATAL_ERROR = 21860
E25090_PI_ERROR_RECORDER_NO_TRACES_CONFIGURED = 25090
E24852_PI_ERROR_RECORDER_ALREADY_REGISTERED = 24852
E24853_PI_ERROR_RECORDER_TRACE_ALREADY_UNSET = 24853
E24932_PI_ERROR_RECORDER_NOT_ENOUGH_RECORDED_DATA = 24932
E25094_PI_ERROR_RECORDER_CONFIGURING_WHILE_RUNNING = 25094
E25095_PI_ERROR_RECORDER_STOP_WHILE_CONFIGURING = 25095
E25607_PI_ERROR_RECORDER_MAX_DATA_RECORDER_NUMBER_REACHED = 25607
E25098_PI_ERROR_RECORDER_PI_ERROR_INVALID_SRC_OPT = 25098
E25099_PI_ERROR_RECORDER_INVALID_SRC_CHAN = 25099
E25209_PI_ERROR_RECORDER_CONFIGURING_WHILE_WAITING_TRG = 25209
E25128_PI_ERROR_RECORDER_TRACE_INDEX_OUT_OF_RANGE = 25128
E25148_PI_ERROR_RECORDER_NOT_FOUND = 25148
E25356_PI_ERROR_RECORDER_INVALID_JUMP = 25356
E25357_PI_ERROR_RECORDER_INVALID_MCM = 25357
E25700_PI_ERROR_RECORDER_NO_REP_RECORDED = 25700
E29028_PI_ERROR_SENSOR_COLLISION_SWITCH_ACTIVATED = 29028
E29194_PI_ERROR_SENSOR_SIGNAL_INVALID = 29194
E29244_PI_ERROR_SENSOR_AUTOZERO_DISABLED = 29244
E29470_PI_ERROR_SENSOR_ABS_OVERFLOW = 29470
E29510_PI_ERROR_SENSOR_ABS_WRITE_ERROR = 29510
E29511_PI_ERROR_SENSOR_ABS_READ_ERROR = 29511
E29540_PI_ERROR_SENSOR_ABS_ERROR = 29540
E29541_PI_ERROR_SENSOR_HW_TEMPERATURE_ERROR = 29541
E29796_PI_ERROR_SENSOR_ABS_CRC_ERROR = 29796
E29797_PI_ERROR_SENSOR_HW_VOLTAGE_ERROR = 29797
E37126_PI_ERROR_SYS_CONTROLLER_BUSY = 37126
E37130_PI_ERROR_SYS_CONNECTION_INPUT_NOT_SET = 37130
E37131_PI_ERROR_SYS_CONNECTION_OUTPUT_NOT_SET = 37131
E37140_PI_ERROR_SYS_ALREADY_HAS_SERIAL_NUMBER = 37140
E37141_PI_ERROR_SYS_INPUT_PORT_ALREADY_CONNECTED = 37141
E37142_PI_ERROR_SYS_UNIT_ALREADY_REGISTERED = 37142
E33084_PI_ERROR_COM_NO_DIGITAL_INPUT = 33084
E33085_PI_ERROR_COM_NO_DIGITAL_OUTPUT = 33085
E37182_PI_ERROR_SYS_FILE_NOT_FOUND = 37182
E37183_PI_ERROR_SYS_LOG_ITEM_NOT_FOUND = 37183
E37184_PI_ERROR_SYS_CONNECTION_NOT_FOUND = 37184
E33124_PI_ERROR_COM_FIRMWARE_STOPPED_BY_CMD = 33124
E33125_PI_ERROR_COM_TOO_MANY_TCP_CONNECTIONS_OPEN = 33125
E33538_PI_ERROR_COM_SOCKET_UNKNOWN_PROTOCOL = 33538
E33546_PI_ERROR_COM_HW_VERSION_ERROR = 33546
E33547_PI_ERROR_COM_FW_VERSION_ERROR = 33547
E37222_PI_ERROR_SYS_INIT_RUNNING = 37222
E37377_PI_ERROR_SYS_WRONG_UNIT_TYPE = 37377
E37388_PI_ERROR_SYS_CONNECTION_BAD_OUTPUT = 37388
E37389_PI_ERROR_SYS_CONNECTION_BAD_INPUT = 37389
E37390_PI_ERROR_SYS_ILLEGAL_FILENAME = 37390
E37391_PI_ERROR_SYS_CONNECTION_NOT_ACCESSIBLE = 37391
E37392_PI_ERROR_SYS_BAD_UNIT_ID = 37392
E37393_PI_ERROR_SYS_INPUT_PORT_NOT_CONNECTED = 37393
E37394_PI_ERROR_SYS_BAD_DEVICE_ID = 37394
E37395_PI_ERROR_SYS_BAD_FUNCTION_ID = 37395
E37396_PI_ERROR_SYS_BAD_PROXY_ID = 37396
E37416_PI_ERROR_SYS_CONNECTION_INDEX_OUT_OF_LIMITS = 37416
E37436_PI_ERROR_SYS_UNIT_NOT_FOUND = 37436
E37639_PI_ERROR_SYS_MAX_CONNECTION_NUMBER_REACHED = 37639
E37682_PI_ERROR_SYS_SAVE_CFG_FAILED = 37682
E37683_PI_ERROR_SYS_LOAD_CFG_FAILED = 37683
E37702_PI_ERROR_SYS_FILE_WRITE_ERROR = 37702
E37732_PI_ERROR_SYS_EEPROM_ERROR = 37732
E33639_PI_ERROR_COM_I2C_ERROR = 33639
E33542_PI_ERROR_COM_COMMUNICATION_BUSY = 33542
E33640_PI_ERROR_COM_COMMUNICATION_ERROR = 33640
E37891_PI_ERROR_SYS_INCORRECT_UNIT_INITIALIZATION = 37891
E33796_PI_ERROR_COM_TIMEOUT = 33796
E33802_PI_ERROR_COM_HW_MATCHCODE_ERROR = 33802
E33803_PI_ERROR_COM_FW_MATCHCODE_ERROR = 33803
E33804_PI_ERROR_COM_INVALID_SOCKET = 33804
E33822_PI_ERROR_COM_RECEIVING_BUFFER_OVERFLOW = 33822
E37919_PI_ERROR_SYS_NOT_ENOUGH_MEMORY = 37919
E37920_PI_ERROR_SYS_BUFFER_EMPTY = 37920
E33824_PI_ERROR_COM_SENDING_BUFFER_OVERFLOW = 33824
E33842_PI_ERROR_COM_FW_UPDATE_ERROR = 33842
E37939_PI_ERROR_SYS_FLASH_PROGRAM_FAILED = 37939
E37940_PI_ERROR_SYS_FLASH_READ_FAILED = 37940
E37941_PI_ERROR_SYS_SECTOR_ERASE_FAILED = 37941
E37942_PI_ERROR_SYS_FLASH_HEADER_DEFECT = 37942
E37943_PI_ERROR_SYS_DEVICE_REGISTRATION_ERROR = 37943
E37944_PI_ERROR_SYS_PROXY_REGISTRATION_ERROR = 37944
E37945_PI_ERROR_SYS_INTERFACE_REGISTRATION_ERROR = 37945
E37948_PI_ERROR_SYS_NO_BIOS_FOUND = 37948
E37958_PI_ERROR_SYS_UMF_BUS_COMMUNICATION_ERROR = 37958
E33892_PI_ERROR_COM_CRC32_ERROR = 33892
E37989_PI_ERROR_SYS_RAM_ERROR = 37989
E37990_PI_ERROR_SYS_HARDWARE_ERROR = 37990
E37991_PI_ERROR_SYS_FATAL_ERROR = 37991
E37992_PI_ERROR_SYS_FW_CRC_FW_ERROR = 37992
E37993_PI_ERROR_SYS_STRING_TO_NUMBER = 37993
E37994_PI_ERROR_SYS_NUMBER_TO_STRING = 37994

# error definition end  ## DO NOT MODIFY THIS LINE!!!


PI_GCS21_ERRORS_ERRORS_DICT_KEY = 'errors'
PI_GCS21_ERRORS_MODULES_DICT_KEY = 'modules'
PI_GCS21_ERRORS_CLASSES_DICT_KEY = 'classes'
PI_GCS21_ERRORS_ID_KEY = 'id'
PI_GCS21_ERRORS_MODULE_KEY = 'module'
PI_GCS21_ERRORS_CLASS_KEY = 'class'
PI_GCS21_ERRORS_DESCRIPTION_KEY = 'description'
PI_GCS21_ERRORS_TYP_KEY = 'typ'
PI_GCS21_ERRORS_VALUE_KEY = 'value'

ERROR_FILE_PATH = os.path.dirname(__file__) + '/Error.json'
POSSIBLE_ERRORS = {}
with open(ERROR_FILE_PATH, 'r') as error_file:
    POSSIBLE_ERRORS = json.load(error_file)


class GCS21Error(PIErrorBase):
    """GCSError exception."""

    def __init__(self, value, message=''):
        """GCSError exception.
        :param value : Error value as integer.
        :param message : Optional message to show in exceptions string representation.
        """
        PIErrorBase.__init__(self, value, message)
        if isinstance(value, GCS21Error):
            self.err = value.err
        else:
            self.err = GCS21Error.get_error_dict(value)
            if self.err:
                self.msg = self.translate_error(self.err)

        debug('GCS21Error: %s', self.msg)

    @staticmethod
    def translate_error(value):
        """Return a readable error message of 'value'.
        :param value : Error value as integer or a gcs21 error dictionary.
        :return : Error message as string if 'value' was an integer else 'value' itself.
        """

        if not isinstance(value, (int, dict)):
            return value

        if isinstance(value, int):
            error_dict = GCS21Error.get_error_dict(value)
        else:
            error_dict = value

        try:
            msg = 'ERROR: ' + str(error_dict[PI_GCS21_ERRORS_VALUE_KEY]) + '\n'
            msg = msg + error_dict[PI_GCS21_ERRORS_MODULE_KEY][PI_GCS21_ERRORS_DESCRIPTION_KEY] + ' (' + str(
                error_dict[PI_GCS21_ERRORS_MODULE_KEY][PI_GCS21_ERRORS_ID_KEY]) + '): '
            msg = msg + error_dict[PI_GCS21_ERRORS_DESCRIPTION_KEY] + ' (' + str(
                error_dict[PI_GCS21_ERRORS_ID_KEY]) + ')\n'
            msg = msg + error_dict[PI_GCS21_ERRORS_CLASS_KEY][PI_GCS21_ERRORS_DESCRIPTION_KEY] + ' (' + str(
                error_dict[PI_GCS21_ERRORS_CLASS_KEY][PI_GCS21_ERRORS_ID_KEY]) + ')\n'
        except KeyError:
            if isinstance(value, int):
                module_id, error_class, error_id = GCS21Error.parse_errorcode(value)
                msg = 'ERROR: ' + str(value) + '\nUnknowen error: module: ' + str(module_id) + ', class: ' + str(
                    error_class) + ', error: ' + str(error_id) + '\n'
            else:
                msg = 'ERROR: Unknowen error\n'

        return msg

    @staticmethod
    def parse_errorcode(error_number):
        """
        parses a error code returnd by the controller into the mocule, class, and error number
        :param error_number: the error code
        :return: [moduel, class, error_number]
        """
        module_id = (error_number & 0x000fff000) >> 12
        error_class = (error_number & 0x00000f00) >> 8
        error_id = error_number & 0x000000ff

        return module_id, error_class, error_id

    @staticmethod
    def parse_to_errorcode(module_id, error_class, error_id):
        """
        parses module id, error class and error id to error number
        :param module_id: the error code
        :type module_id: int
        :param error_class: the error class
        :type error_class: int
        :param error_id: the error id
        :type error_id: int
        :return: error_number
        """
        error_number = ((module_id << 12) & 0x000fff000) | \
                       ((error_class << 8) & 0x00000f00) | \
                       (error_id & 0x000000ff)
        return error_number

    @staticmethod
    def get_error_dict(error_number):
        """
        gets the gcs21 error dictionary form the error number
        :param error_number:
        :return:
        """
        error_dict = {}
        module_id, error_class, error_id = GCS21Error.parse_errorcode(error_number)
        #    module_id = (error_number & 0xf800) >> 11
        #    error_class = (error_number & 0x0700) >> 8
        #    error_id = error_number & 0x00ff

        module_dict = {}
        for module in POSSIBLE_ERRORS[PI_GCS21_ERRORS_MODULES_DICT_KEY]:
            if POSSIBLE_ERRORS[PI_GCS21_ERRORS_MODULES_DICT_KEY][module][PI_GCS21_ERRORS_ID_KEY] == module_id:
                module_dict = POSSIBLE_ERRORS[PI_GCS21_ERRORS_MODULES_DICT_KEY][module]
                module_dict[PI_GCS21_ERRORS_TYP_KEY] = module

        classes_dict = {}
        for classe in POSSIBLE_ERRORS[PI_GCS21_ERRORS_CLASSES_DICT_KEY]:
            if POSSIBLE_ERRORS[PI_GCS21_ERRORS_CLASSES_DICT_KEY][classe][PI_GCS21_ERRORS_ID_KEY] == error_class:
                classes_dict = POSSIBLE_ERRORS[PI_GCS21_ERRORS_CLASSES_DICT_KEY][classe]
                classes_dict[PI_GCS21_ERRORS_TYP_KEY] = classe

        # Wrong hanging indentation before block (add 4 spaces).  pylint: disable = C0330
        for err in POSSIBLE_ERRORS[PI_GCS21_ERRORS_ERRORS_DICT_KEY]:
            if POSSIBLE_ERRORS[PI_GCS21_ERRORS_ERRORS_DICT_KEY][err][PI_GCS21_ERRORS_ID_KEY] == error_id and \
                    POSSIBLE_ERRORS[PI_GCS21_ERRORS_ERRORS_DICT_KEY][err][
                        PI_GCS21_ERRORS_CLASS_KEY] == classes_dict[PI_GCS21_ERRORS_TYP_KEY] and \
                    POSSIBLE_ERRORS[PI_GCS21_ERRORS_ERRORS_DICT_KEY][err][
                        PI_GCS21_ERRORS_MODULE_KEY] == module_dict[PI_GCS21_ERRORS_TYP_KEY]:
                error_dict = {PI_GCS21_ERRORS_TYP_KEY: err}
                error_dict[PI_GCS21_ERRORS_MODULE_KEY] = module_dict
                error_dict[PI_GCS21_ERRORS_CLASS_KEY] = classes_dict
                error_dict[PI_GCS21_ERRORS_ID_KEY] = POSSIBLE_ERRORS[PI_GCS21_ERRORS_ERRORS_DICT_KEY][err][
                    PI_GCS21_ERRORS_ID_KEY]
                error_dict[PI_GCS21_ERRORS_DESCRIPTION_KEY] = POSSIBLE_ERRORS[PI_GCS21_ERRORS_ERRORS_DICT_KEY][err][
                    PI_GCS21_ERRORS_DESCRIPTION_KEY]
                error_dict[PI_GCS21_ERRORS_VALUE_KEY] = error_number

        return error_dict
