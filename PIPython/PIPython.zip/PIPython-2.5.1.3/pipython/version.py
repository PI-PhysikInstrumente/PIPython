#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.5.1.3'
__signature__ = 0x170eee0a3ddf54d6363d2c5ec9399a3a
