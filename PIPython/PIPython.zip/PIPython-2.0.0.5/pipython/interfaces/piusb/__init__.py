#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
# Wildcard import pipython.pidevice.interfaces.piusb pylint: disable=W0401
from pipython.pidevice.interfaces.piusb import *

warnings.warn("Please use 'pipython.pidevice.interfaces.piusb' instead", DeprecationWarning)

__all__ = ['PIUSB']

__signature__ = 0xa8cb0d5837daf59829e1a4652dcd76b3
