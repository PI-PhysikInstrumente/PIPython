#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.7.0.14'
__signature__ = 0x51f2a36bea2a2a99416202002696579b
