#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.3.0.2'
__signature__ = 0xfe137c599db17b48a2732b56dbff353f
