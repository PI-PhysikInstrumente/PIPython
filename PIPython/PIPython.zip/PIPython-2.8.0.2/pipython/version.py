#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.8.0.2'
__signature__ = 0x8045a95fc4c3db3b9a0bd6e327bc78fb
