#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.9.0.4'
__signature__ = 0x640c6041f84d32377c6b1b428ba7bc45
