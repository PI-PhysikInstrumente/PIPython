#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.5.1.1'
__signature__ = 0x79027ba883bd4e9f5f8f623d35b423d
