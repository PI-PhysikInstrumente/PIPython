#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of gcs21 tools."""
__signature__ = 0x41b4a8351a5c036efb35f692426943e
