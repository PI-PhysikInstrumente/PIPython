#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.7.0.6'
__signature__ = 0xe0fbb7f2fdb91d85c8a5346d26e89c2c
