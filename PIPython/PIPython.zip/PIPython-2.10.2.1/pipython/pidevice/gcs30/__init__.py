#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of UMF container unit modules."""

__signature__ = 0x292c621ad850ae0a273ffb3cfd0db71
