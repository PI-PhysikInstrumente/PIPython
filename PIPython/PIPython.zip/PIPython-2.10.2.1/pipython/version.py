#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.10.2.1'
__signature__ = 0xf1a8340c7a7034d1700e0cda20e6b305
