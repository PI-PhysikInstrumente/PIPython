#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.6.0.3'
__signature__ = 0x6b770d8eb9f89751e38de3008d31bf8e
