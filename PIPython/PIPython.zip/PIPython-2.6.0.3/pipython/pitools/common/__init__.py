#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of common gcs tools."""
__signature__ = 0x6b9d0bfdfd318773e441964d24bd6df6
