#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.10.0.1'
__signature__ = 0x2738a4661992cffece2cf356a8d0da3d
