#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.6.1.1'
__signature__ = 0xab9e019cd1cd230bdedddde5d76c2774
