#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
# Wildcard import pipython.pidevice.gcserror pylint: disable=W0401
from pipython.pidevice.piparams import *

warnings.warn("Please use 'pipython.pidevice.piparams' instead", DeprecationWarning)

__signature__ = 0xa227b1e02c12d346a625ec5bde9c8f2a
