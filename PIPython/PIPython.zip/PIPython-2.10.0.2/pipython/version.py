#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.10.0.2'
__signature__ = 0x2e9ed52ba06b61558711f0635c5e85a9
