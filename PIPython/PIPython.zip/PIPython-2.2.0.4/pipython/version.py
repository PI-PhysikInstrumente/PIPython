#!/usr/bin/python
# -*- coding: utf-8 -*-
""" Versions informations."""

__version__ = '2.2.0.4'
__signature__ = 0xb00d489bfdf87c3d8091a248b6e70ff4
