#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import pipython.gcserror
from pipython.gcserror import GCSError
from pipython.gcsdevice import GCSDevice

__version__ = '1.5.3.1'
__signature__ = 0x8ac155d8b3f3c759f09705ffad7a733
