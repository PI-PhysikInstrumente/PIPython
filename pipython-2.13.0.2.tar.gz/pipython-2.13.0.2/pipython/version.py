#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Version information."""

__version__ = '2.13.0.2'
__signature__ = 0x8298ae7591a028037c6129523d1f6588
