#!/usr/bin/python
# -*- coding: utf-8 -*-

"""This example helps you to get used to PIPython."""

import time
import sys
from pipython import GCSDevice, pitools

__signature__ = 0x14047c0a542176d9d4e0da0a33f15e8

# Use PIControllerEmulatorGCS3.0 provided with the PISoftwareSuite
AXES = ['AXIS_1', 'AXIS_2']
REFMODES = ['FRF', 'FRF']
CONTROLMODES = {'AXIS_1': 2, 'AXIS_2': 2}


def homing_axes(pidevice : GCSDevice):
    for axis in AXES:
        max_velocity = pidevice.qSPV('RAM', axis, 'TRAJ_1', '0x105')['RAM'][axis]['TRAJ_1']['0x105']
        pidevice.VEL(axis, max_velocity)
        pidevice.MOV(axis, 0)

    pitools.waitontarget(pidevice, axes=AXES)


def move_axes_to_targets(pidevice : GCSDevice, axis_1_target, axis_2_target):
    if len(pidevice.axes) < 2:
        print('Error: Sample requires at least two axes')
        return

    # Set user level to advanced
    pidevice.UCL('adv', 'advanced')

    # Delete previous connections and disable trigger to achieve idempotency. The code below makes
    # 4 connections (LNK_1 1-4) which are deleted here, in case of running the sample multiple times.
    pidevice.LNK_UDEL('LNK_1', 1)
    pidevice.LNK_UDEL('LNK_1', 2)
    pidevice.LNK_UDEL('LNK_1', 3)
    pidevice.LNK_UDEL('LNK_1', 4)
    pidevice.TRG_DISABLE('TRG_1')

    # Connect on-target outputs to expression unit
    pidevice.LNK_USER('LNK_1', 1, 'AXIS_1', '-', '0x110', 'SYS_1', 'EXPR_1', '0x101,1')
    pidevice.LNK_USER('LNK_1', 2, 'AXIS_2', '-', '0x110', 'SYS_1', 'EXPR_1', '0x101,2')

    # Connect expression output to trigger unit input
    pidevice.LNK_USER('LNK_1', 3, 'SYS_1', 'EXPR_1', '0x104', 'TRG_1', '-', '0x102')
    # Connect trigger unit output to IO_1
    pidevice.LNK_USER('LNK_1', 4, 'TRG_1', '-', '0x103', 'IO_1', '-', '0x111,1')

    # Create expression with AND logic
    pidevice.SPV('RAM', 'SYS_1', 'EXPR_1', '0x105', 'P1&&P2')

    # Set trigger event raising edge
    pidevice.SPV('RAM', 'TRG_1', '-', '0x105', '0')
    # Debounce using 10 servo cycles
    pidevice.SPV('RAM', 'TRG_1', '-', '0x106', '10')
    # Choose trigger output signal type bypass
    pidevice.SPV('RAM', 'TRG_1', '-', '0x10A', '2')
    # Enable trigger event
    pidevice.TRG_ENABLE('TRG_1')

    # Set slow speed for observation of the I/O change
    pidevice.VEL(pidevice.axes[0], '0.1')
    pidevice.VEL(pidevice.axes[1], '0.07')  # slightly slower than the first axis

    # Move axes to target
    pidevice.MOV(pidevice.axes[0], axis_1_target)
    pidevice.MOV(pidevice.axes[1], axis_2_target)

    # Wait until both axes reached the target checking IO_1
    print('Waiting until axes reached their targets checking IO_1:')
    io_1 = 0
    for step in range(60):
        axis_1_pos = pidevice.qPOS(pidevice.axes[0])
        axis_2_pos = pidevice.qPOS(pidevice.axes[1])

        # Read the output signal which is set by the trigger above
        io_1 = pidevice.qSPV('RAM', 'IO_1', '-', '0x111,1')['RAM']['IO_1']['-']['0x111,1']

        if step > 0:  # move cursor 3 lines up
            sys.stdout.write("\033[F\033[F\033[F")
        sys.stdout.write(f'  {pidevice.axes[0]}: Target: {axis_1_target:.3f} Actual: {axis_1_pos[pidevice.axes[0]]:.3f}\n')
        sys.stdout.write(f'  {pidevice.axes[1]}: Target: {axis_2_target:.3f} Actual: {axis_2_pos[pidevice.axes[1]]:.3f}\n')
        sys.stdout.write(f"  Waiting for IO_1 {'.' * step} {'[ok]' if io_1 else ''}\n")
        sys.stdout.flush()
        time.sleep(1)

        if io_1:
            break
    if io_1:
        print('Both axes reached their targets.')
    else:
        print('Timeout while waiting for IO_1.')


def main():
    with GCSDevice() as pidevice:

        pidevice.ConnectTCPIP(ipaddress='localhost')
        # pidevice.ConnectUSB(serialnum='123456789')
        # pidevice.ConnectRS232(comport=1, baudrate=115200)

        print('Connected: {}'.format(pidevice.qIDN().strip()))

        if pidevice.HasqVER():
            print('Version info:\n{}'.format(pidevice.qVER().strip()))

        print('Initialize connected stages ...')
        pitools.startup(pidevice, stages=AXES, refmodes=REFMODES, controlmodes=CONTROLMODES)

        print('Move two axes and wait for being on targets ...')
        homing_axes(pidevice)
        move_axes_to_targets(pidevice, 1, 1)


if __name__ == '__main__':
    main()
