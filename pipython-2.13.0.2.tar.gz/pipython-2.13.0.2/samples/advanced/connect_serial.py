#!/usr/bin/python
# -*- coding: utf-8 -*-
"""This example shows how to connect PIPython via serial port."""

# (c)2016 Physik Instrumente (PI) SE & Co. KG
# Software products that are provided by PI are subject to the
# General Software License Agreement of Physik Instrumente (PI) SE & Co. KG
# and may incorporate and/or make use of third-party software components.
# For more information, please read the General Software License Agreement
# and the Third Party Software Note linked below.
# General Software License Agreement:
# https://www.physikinstrumente.com/fileadmin/user_upload/physik_instrumente/files/legal/General-Software-License-Agreement-Physik-Instrumente.pdf
# Third Party Software Note:
# https://www.physikinstrumente.com/fileadmin/user_upload/physik_instrumente/files/legal/Third-Party-Software-Note-Physik-Instrumente.pdf


import sys

from pipython.pidevice.gcscommands import GCSCommands
from pipython.pidevice.gcsmessages import GCSMessages
from pipython.pidevice.interfaces.piserial import PISerial

__signature__ = 0x827cd4d873d9ef3465ec96e6ae40f0f2


def main():
    """Connect controller via first serial port with 115200 baud."""
    if sys.platform in ('linux', 'linux2', 'darwin'):
        port = '/dev/ttyS0'  # use '/dev/ttyUSB0' for FTDI-USB connections
    else:
        port = 'COM1'
    with PISerial(port=port, baudrate=115200) as gateway:
        print('interface: {}'.format(gateway))
        messages = GCSMessages(gateway)
        with GCSCommands(messages) as pidevice:
            print('connected: {}'.format(pidevice.qIDN().strip()))


if __name__ == '__main__':
    # from pipython import PILogger, DEBUG, INFO, WARNING, ERROR, CRITICAL
    # PILogger.setLevel(DEBUG)
    main()
