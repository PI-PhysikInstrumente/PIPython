#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
from pipython.pidevice.gcserror import *

warnings.warn("Please use 'pipython.pidevice.gcserror' instead", DeprecationWarning)

__all__ = ['GCSError']

__signature__ = 0x39e6a8bad4fc8843e1309dbbdc9481f9
