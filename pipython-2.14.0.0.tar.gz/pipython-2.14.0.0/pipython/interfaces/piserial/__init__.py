#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
from pipython.pidevice.interfaces.piserial import *

warnings.warn("Please use 'pipython.pidevice.interfaces.piserial' instead", DeprecationWarning)

__all__ = ['PISerial']

__signature__ = 0x7137408689eb0388067121cd6941ceff
