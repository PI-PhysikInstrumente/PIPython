#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
from pipython.pidevice.interfaces.pisocket import *

warnings.warn("Please use 'pipython.pidevice.interfaces.pisocket' instead", DeprecationWarning)

__all__ = ['PISocket']

__signature__ = 0xd9a1be7606500cfd53ef358f3b888a18
