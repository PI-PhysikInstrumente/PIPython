#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
from pipython.pidevice.interfaces.piusb import *

warnings.warn("Please use 'pipython.pidevice.interfaces.piusb' instead", DeprecationWarning)

__all__ = ['PIUSB']

__signature__ = 0x8634ed9760b12a69299d7075f6d087db
