#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
from pipython.pidevice.interfaces.gcsdll import *

warnings.warn("Please use 'pipython.pidevice.interfaces.gcsdll' instead", DeprecationWarning)

__all__ = ['GCSDll']

__signature__ = 0x8f9a65a90f30dd81042a5452f444ffdb
