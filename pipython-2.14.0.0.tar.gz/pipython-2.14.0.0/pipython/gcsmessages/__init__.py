#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Collection of libraries to use PI controllers and process GCS data."""

import warnings
from pipython.pidevice.gcsmessages import *

warnings.warn("Please use 'pipython.pidevice.gcsmessages' instead", DeprecationWarning)

__all__ = ['GCSMessages']

__signature__ = 0x65d1b728536837bd3baf8f43d3e82492
