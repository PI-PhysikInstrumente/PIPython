#!/usr/bin python
# -*- coding: utf-8 -*-
"""Provide GCSError defines and GCSError exception class."""
# line too long pylint: disable=C0301

import json
import os

from ...PILogger import PIDebug
from ..pierror_base import PIErrorBase

__signature__ = 0x2fa9aa48832896888d230dc267e4fa5e

# /*!
#  * \brief Structure of an UMF error.
#  * \- RSD:   		Reserved bit
#  * \- FGroup ID: 	Functional Group ID
#  * \- Error Class:  Config or Processing error
#  * \- Error Code:   The error code
#  *  _______________________________________________________________________________________________________________________________
#  * |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |   |
#  * |               Reserve                 |          ErrorClass           |                     ErrorID                           |
#  * |___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|___|
#  *
#  */

# error definition begin  ## DO NOT MODIFY THIS LINE!!!
E0_NO_ERROR = 0
E49154_NUMBER_OF_ARGUMENTS = 49154
E49155_UNKNOWN_COMMAND = 49155
E49156_COMMAND_LEVEL_TOO_LOW_FOR_COMMAND_ACCESS = 49156
E49157_INVALID_PWD = 49157
E49158_UNKNOWN_SECTION_COMMAND = 49158
E49159_INVALID_CHAR = 49159
E81928_STP = 81928
E4177929_WRONG_DATA_TYPE = 4177929
E49161_WRONG_DATA_TYPE = 49161
E49162_UNKNOWN_PARAMETER_ID = 49162
E49163_COMMAND_LEVEL_TOO_LOW_FOR_PARAMETER_ACCESS = 49163
E49164_INVALID_VALUE = 49164
E49165_WRONG_PARAMETER_TYPE = 49165
E49166_VALUE_OUT_OF_RANGE = 49166
E32782_VALUE_OUT_OF_RANGE = 32782
E49167_UNKNOWN_AXIS_ID = 49167
E49168_ON_LIMIT_SWITCH = 49168
E49169_INVALID_MODE_OF_OPERATION = 49169
E49170_AXIS_NOT_REF = 49170
E81938_AXIS_NOT_REF = 81938
E49171_INVALID_AXIS_STATE = 49171
E49172_TARGET_OUT_OF_RANGE = 49172
E32788_TARGET_OUT_OF_RANGE = 32788
E49173_AXIS_DISABLED = 49173
E49174_FAULT_REACTION_ACTIVE = 49174
E81943_LIMIT_SWITCH_ACTIVATED = 81943
E81944_OVER_CURRENT_PROTECTION = 81944
E32793_OUTPUT_LIMIT = 32793
E81946_POSITION_ERROR_TOO_LARGE = 81946
E81947_STOP = 81947
E4177948_MAX_DATA_RECORDER_NUMBER_REACHED = 4177948
E4177949_ALREADY_REGISTERED = 4177949
E49182_WRONG_FORMAT = 49182
E49183_UNKNOWN_RECORDER_ID = 49183
E49184_NOT_IN_CONFIG_MODE = 49184
E49185_WRONG_RECORDER_TRIGGER = 49185
E49186_WRONG_STARTPOINT = 49186
E49187_WRONG_NUMPOINT = 49187
E49188_ALREADY_RUNNING = 49188
E49189_TRACE_DOES_NOT_EXIST = 49189
E49190_NOT_ENOUGH_RECORDED_DATA = 49190
E49191_TRACES_NOT_CONFIGURED = 49191
E32808_COMMUNICATION_ERROR = 32808
E49193_FW_INDEX_UNKNOWN = 49193
E65578_TIMEOUT = 65578
E65579_INVALID_SOCKET = 65579
E4177964_WRONG_UNIT_ID_FORMAT = 4177964
E4177965_UNIT_NOT_INITIALIZED = 4177965
E4177966_MAX_CONNECTION_NUMBER_REACHED = 4177966
E4177967_CONNECTION_OUTPUT_WRONG_ARGUMENTS = 4177967
E4177968_CONNECTION_INPUT_WRONG_ARGUMENTS = 4177968
E4177969_WRONG_DEVICE_ID = 4177969
E4177970_WRONG_FUNCTION_ID = 4177970
E4177971_WRONG_PROXY_ID = 4177971
E4177972_CONNECTION_OUTPUT_INDEX_OUT_OF_RANGE = 4177972
E4177973_INTERFACE_REGISTRATION_FAILED = 4177973
E4177974_DEVICE_REGISTRATION_FAILED = 4177974
E4177975_PROXY_REGISTRATION_FAILED = 4177975
E16440_INPUT_PORT_ALREADY_CONNECTED = 16440
E49208_INPUT_PORT_ALREADY_CONNECTED = 49208
E16441_UNIT_ALREADY_REGISTERED = 16441
E16442_CONNECTION_HAS_NO_INPUT = 16442
E49210_CONNECTION_HAS_NO_INPUT = 49210
E16443_CONNECTION_HAS_NO_OUTPUT = 16443
E49211_CONNECTION_HAS_NO_OUTPUT = 49211
E16444_CONNECTION_NOT_FOUND = 16444
E49212_CONNECTION_NOT_FOUND = 49212
E16445_INPUT_PORT_NOT_CONNECTED = 16445
E49213_INPUT_PORT_NOT_CONNECTED = 49213
E65597_INPUT_PORT_NOT_CONNECTED = 65597
E32830_DATA_CORRUPT = 32830
E49215_UNIT_TYPE_NOT_SUPPORTED = 49215
E65599_UNIT_TYPE_NOT_SUPPORTED = 65599
E49216_FW_UPDATE_ERROR = 49216
E49217_UNIT_NOT_FOUND = 49217
E49218_CUNIT_NOT_FOUND = 49218
E49219_FUNIT_NOT_FOUND = 49219
E65604_NOT_ENOUGH_MEMORY = 65604
E49220_NOT_ENOUGH_MEMORY = 49220
E65605_FLASH_READ_FAILED = 65605
E65606_NO_DATA_AVAILABLE = 65606
E65607_FATAL_ERROR = 65607
E49224_AXIS_IN_FAULT = 49224
E81993_REF_SIGNAL_NOT_FOUND = 81993
E65609_REF_SIGNAL_NOT_FOUND = 65609
E65610_TIMEOUT = 65610
E49227_ON_IPR = 49227
E16459_ON_IPR = 16459
E4177996_HALT_WAS_COMMANDED = 4177996
E49229_EXPR_INVALID = 49229
E49230_EXPR_TOO_COMPLEX = 49230
E49231_LNK_ALREADY_SET = 49231
E49232_LNK_WRONG_INDEX = 49232
E49233_CUNIT_INPUT_NOT_FOUND = 49233
E49234_FUNIT_INPUT_NOT_FOUND = 49234
E49235_CUNIT_OUTPUT_NOT_FOUND = 49235
E49236_FUNIT_OUTPUT_NOT_FOUND = 49236
E49237_UNKNOWN_TRIGGER_ID = 49237
E16470_AUTOMATIC_ADAPTATION_TO_NEW_LIMIT = 16470
E49239_REFERENCING_VELOCITY_OUT_OF_BOUNDS = 49239
E49240_QUICK_STOP_ACTIVE = 49240
E32857_EXPR_EVAL_TO_NAN_OR_INF = 32857
E49242_UNKNOWN_LINK_ID = 49242
E49243_PARAMETER_ID_INPUT_NOT_FOUND = 49243
E49244_PARAMETER_ID_OUTPUT_NOT_FOUND = 49244
E49245_TRG_IS_ENABLED = 49245
E82014_INPUT_VOLTAGE_LIMIT_VIOLATION = 82014
E82015_DRIVE_INITIALIZATION_FAILED = 82015
E4178016_ANGLE_OFFSET_DETERMINATION_CTRL_SEARCH_FAILED = 4178016
E4178017_ANGLE_OFFSET_DETERMINATION_CHECK_DIRECTION_FAILED = 4178017
E82018_OVERVOLTAGE_PROTECTION = 82018
E65635_OVERHEATING_PROTECTION = 65635
E65637_INDEX_RANGE = 65637
E32870_MEMORY_LOCKED = 32870
E49255_SEQUENCE_DOES_NOT_EXIST = 49255
E49256_UNKNOWN_SEQUENCER_ID = 49256
E49258_INVALID_INDEX = 49258
E16491_END_OF_EXECUTIONPLAN = 16491
E32876_EXECUTIONPLAN_LOCKED = 32876
E49261_WRONG_STATE = 49261
E49262_TRIGGER_ENABLED = 49262
E49263_SERVOCYCLEINDEX_IN_USE = 49263
E65648_LOADING_SEQ_FAILED = 65648
E16497_EXECUTION_END = 16497
E49266_ITEM_NOT_LOADED = 49266
E65651_FATAL_OVERHEATING_EVENT = 65651
E65652_NO_EXTERNAL_CLOCK = 65652
E65653_BAD_EXTERNAL_CLOCK = 65653
E16502_CLOCK_CHANGED_TO_STANDALONE = 16502
E16503_CLOCK_CHANGED_TO_SLAVE = 16503
E16504_CLOCK_CHANGED_TO_MASTER = 16504
E65657_NO_EXTERNAL_SYNC_PULSE = 65657
E16506_RESET_OCCURED = 16506
E65659_PROCEDURE_NOT_AVAILABLE = 65659
E16508_AXIS_HAS_ABSOLUTE_SENSOR = 16508
E49277_COMMAND_NOT_SUPPORTED_BY_UNIT = 49277
E49278_MAX_NUM_SUBSEQ = 49278
E65663_NO_ID_CHIP_CONNECTED = 65663
E65664_CORRUPT_ID_CHIP_ENTRIES = 65664
E16513_LOADED_ID_CHIP_DATA = 16513
E65666_MISSING_ID_CHIP_ENTRIES = 65666
E65667_ID_CHIP_VALUE_OUT_OF_RANGE = 65667
E65668_ID_CHIP_STRING_VALUE_TOO_LONG = 65668
E16517_SDRAM_CHECK_PASSED = 16517
E32902_SDRAM_CHECK_FAILED = 32902
E49287_SEQUENCE_ALREADY_EXISTS = 49287
E32904_INTERFACE_LOCKED = 32904
E49289_OFFSET_NOT_SUPPORTED = 49289
E49290_ALREADY_READY = 49290
E49291_ALREADY_RUNNING = 49291
E49292_LINE_TOO_LONG = 49292
E65677_INDEX_OUT_OF_RANGE = 65677

# error definition end  ## DO NOT MODIFY THIS LINE!!!


PI_GCS30_ERRORS_ERRORS_DICT_KEY = 'errors'
PI_GCS30_ERRORS_CLASSES_DICT_KEY = 'classes'
PI_GCS30_ERRORS_MODULES_DICT_KEY = 'modules'
PI_GCS30_ERRORS_ID_KEY = 'id'
PI_GCS30_ERRORS_CLASS_KEY = 'class'
PI_GCS30_ERRORS_MODULE_KEY = 'module'
PI_GCS30_ERRORS_DESCRIPTION_KEY = 'description'
PI_GCS30_ERRORS_TYP_KEY = 'typ'
PI_GCS30_ERRORS_VALUE_KEY = 'value'
PI_GCS30_ERRORS_ALIAS_KEY = 'alias'

ERROR_FILE_PATH = os.path.dirname(__file__) + '/CustomError.json'
# Variable name "POSSIBLE_ERRORS" doesn't conform to snake_case naming style pylint: disable=C0103
POSSIBLE_ERRORS = {}

def parse_error_jdson(file_name):
    """
    Parses the jdson file 'file_name' into a dictionary which is used by the PIPython to handle the errors
    :param file_name: the GCS3 3.0 Error jdson file (path and file)
    :return: dic which ist used by PIPython to handle the errors
    """
    possible_errors = {}
    error_jdson = json.load(file_name)
    for dict_key in error_jdson:
        if dict_key == PI_GCS30_ERRORS_ERRORS_DICT_KEY:
            possible_errors[PI_GCS30_ERRORS_ERRORS_DICT_KEY] = {}
            for err_id in error_jdson[PI_GCS30_ERRORS_ERRORS_DICT_KEY]:
                for _ in error_jdson[PI_GCS30_ERRORS_ERRORS_DICT_KEY][err_id][PI_GCS30_ERRORS_CLASS_KEY]:
                    if ':' in err_id:
                        error_id = int(err_id.split(':')[0])
                        error_name = err_id.split(':')[1]
                    else:
                        error_name = err_id

                    error_dict = error_jdson[PI_GCS30_ERRORS_ERRORS_DICT_KEY][err_id].copy()
                    if ':' in err_id:
                        error_dict[PI_GCS30_ERRORS_ID_KEY] = error_id

                    possible_errors[PI_GCS30_ERRORS_ERRORS_DICT_KEY][error_name] = error_dict

        else:
            possible_errors[dict_key] = error_jdson[dict_key]

    return possible_errors

with open(ERROR_FILE_PATH, 'r', encoding='utf-8') as error_file:
    POSSIBLE_ERRORS = parse_error_jdson(error_file)

class GCS30Error(PIErrorBase):
    """GCSError exception."""

    def __init__(self, value, message=''):
        """GCSError exception.
        :param value : Error value as integer.
        :param message : Optional message to show in exceptions string representation.
        """
        PIErrorBase.__init__(self, value, message)
        if isinstance(value, GCS30Error):
            self.err = value.err
        else:
            self.err = GCS30Error.get_error_dict(value)
            if self.err:
                self.msg = self.translate_error(self.err)

        PIDebug('GCS30Error: %s', self.msg)

    @staticmethod
    def translate_error(value):
        """Return a readable error message of 'value'.
        :param value : Error value as integer or a gcs30 error dictionary.
        :return : Error message as string if 'value' was an integer else 'value' itself.
        """

        if not isinstance(value, (int, dict)):
            return value

        if isinstance(value, int):
            error_dict = GCS30Error.get_error_dict(value)
        else:
            error_dict = value

        try:
            msg = 'ERROR: ' + str(error_dict[PI_GCS30_ERRORS_VALUE_KEY]) + '\n'
            msg = msg + error_dict[PI_GCS30_ERRORS_DESCRIPTION_KEY] + ' (' + str(
                error_dict[PI_GCS30_ERRORS_ID_KEY]) + ')\n'
            msg = msg + error_dict[PI_GCS30_ERRORS_CLASS_KEY][PI_GCS30_ERRORS_DESCRIPTION_KEY] + ' (' + str(
                error_dict[PI_GCS30_ERRORS_CLASS_KEY][PI_GCS30_ERRORS_ID_KEY]) + ')\n'
        except KeyError:
            if isinstance(value, int):
                error_class, error_id = GCS30Error.parse_errorcode(value)
                msg = 'ERROR: ' + str(value) + '\nUnknown error: class: ' + str(
                    error_class) + ', error: ' + str(error_id) + '\n'
            else:
                msg = 'ERROR: Unknown error\n'

        return msg

    @staticmethod
    def parse_errorcode(error_number):
        """
        parses an error code returned by the controller into the module, class, and error number
        :param error_number: the error code
        :return: [module, class, error_number]
        """
        error_class = (error_number & 0x003FC000) >> 14
        error_id = error_number & 0x00003fff

        return error_class, error_id

    @staticmethod
    def parse_to_errorcode(error_class, error_id):
        """
        parses module id, error class and error id to error number
        :type module_id: int
        :param error_class: the error class
        :type error_class: int
        :param error_id: the error id
        :type error_id: int
        :return: error_number
        """
        error_number = (((error_class << 14) & 0x003FC000) | \
                       (error_id & 0x00003fff))
        return error_number

    @staticmethod
    def get_error_dict(error_number):
        """
        gets the gcs30 error dictionary form the error number
        :param error_number:
        :return:
        """
        error_dict = {}
        error_class, error_id = GCS30Error.parse_errorcode(error_number)

        classes_dict = {}
        for classe in POSSIBLE_ERRORS[PI_GCS30_ERRORS_CLASSES_DICT_KEY]:
            if POSSIBLE_ERRORS[PI_GCS30_ERRORS_CLASSES_DICT_KEY][classe][PI_GCS30_ERRORS_ID_KEY] == error_class:
                classes_dict = POSSIBLE_ERRORS[PI_GCS30_ERRORS_CLASSES_DICT_KEY][classe]
                classes_dict[PI_GCS30_ERRORS_TYP_KEY] = classe

        for err in POSSIBLE_ERRORS[PI_GCS30_ERRORS_ERRORS_DICT_KEY]:
            if POSSIBLE_ERRORS[PI_GCS30_ERRORS_ERRORS_DICT_KEY][err][PI_GCS30_ERRORS_ID_KEY] == error_id and \
                    classes_dict[PI_GCS30_ERRORS_TYP_KEY] in POSSIBLE_ERRORS[PI_GCS30_ERRORS_ERRORS_DICT_KEY][err][
                        PI_GCS30_ERRORS_CLASS_KEY]:
                error_dict = {PI_GCS30_ERRORS_TYP_KEY: err}
                error_dict[PI_GCS30_ERRORS_CLASS_KEY] = classes_dict
                error_dict[PI_GCS30_ERRORS_ID_KEY] = POSSIBLE_ERRORS[PI_GCS30_ERRORS_ERRORS_DICT_KEY][err][
                    PI_GCS30_ERRORS_ID_KEY]
                error_dict[PI_GCS30_ERRORS_DESCRIPTION_KEY] = POSSIBLE_ERRORS[PI_GCS30_ERRORS_ERRORS_DICT_KEY][err][
                    PI_GCS30_ERRORS_DESCRIPTION_KEY]
                error_dict[PI_GCS30_ERRORS_VALUE_KEY] = error_number

        return error_dict
