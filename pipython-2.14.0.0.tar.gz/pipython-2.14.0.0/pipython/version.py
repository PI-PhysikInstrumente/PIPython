#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Version information."""

__version__ = '2.14.0.0'
__signature__ = 0xa7782b643d4acf1b65beee98e990b84b
