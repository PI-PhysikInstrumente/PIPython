#!/usr/bin/python
# -*- coding: utf-8 -*-

"""This example shows how to use the sequencer."""

# (c) 2021 Physik Instrumente (PI) SE & Co. KG
# Software products that are provided by PI are subject to the
# General Software License Agreement of Physik Instrumente (PI) SE & Co. KG
# and may incorporate and/or make use of third-party software components.
# For more information, please read the General Software License Agreement
# and the Third Party Software Note linked below.
# General Software License Agreement:
# https://www.physikinstrumente.com/fileadmin/user_upload/physik_instrumente/files/legal/General-Software-License-Agreement-Physik-Instrumente.pdf
# Third Party Software Note:
# https://www.physikinstrumente.com/fileadmin/user_upload/physik_instrumente/files/legal/Third-Party-Software-Note-Physik-Instrumente.pdf

from dataclasses import dataclass
from pipython import GCSDevice, datarectools, pitools


__signature__ = 0xb22e6f3e5163aa7e4144f887ee503f7

@dataclass(frozen=True)
class SequenceId:
    sequence_set_id: int
    index: int

    def __str__(self) -> str:
        return f"{self.sequence_set_id},{self.index}"

PI_TRUE = 1
PI_FALSE = 0

TRIGGER_MODE_SIGNAL = 'SIGNAL'

AXIS_ID = 'AXIS_1'
SEQUENCER_ID = 'SQEN_1'
RECORDER_ID = 'REC_1'
LINK_ID = 'LNK_1'

NO_FUNCTION_UNIT = '-'

DATA_TYPE_FLOAT = 'FLOAT64'
DATA_TYPE_BOOL = 'BIT'

USER_LEVEL_ADVANCED = 'ADV'
USER_LEVEL_ADVANCED_PASSWORD = 'advanced'

PLAN_ITEM_INDEX_1 = 1
PLAN_ITEM_INDEX_2 = 2

SERVO_CYCLE_INDEX_1 = 1
SERVO_CYCLE_INDEX_2 = 2

SUPPORTING_POINT_DISTANCE_1 = 1

SINGLE_EXECUTION = 1

ONE_VALUE = 1
VALUE_INDEX_1 = 1

BUFFER_SIZE = 1024

TRACE_ID_1 = 1
TRACE_ID_2 = 2
TRACE_ID_3 = 3
TRACE_ID_4 = 4

NO_OF_TRACES = 4

LINK_INDEX_1 = 1

SEQUENCE_ID_IMPULSE_HIGH = SequenceId(1, 1)
SEQUENCE_ID_IMPULSE_LOW = SequenceId(2, 1)
SEQUENCE_ID_TRIGGER_HIGH = SequenceId(3, 1)
SEQUENCE_ID_TRIGGER_LOW = SequenceId(4, 1)

IMPULSE_AMPLITUDE = 1.0
IMPULSE_DURATION_SERVO_CYCLES = 500
TOTAL_DURATION_SERVO_CYCLES = 1500

RECORDING_RATE = 1

CONTROLLERNAME = 'E-880'  # 'C-884' will also work
REFERENCING_MODES = ['FRF', 'FRF']
CONTROL_MODES = {'AXIS_1': 8, 'AXIS_2': 8}


def main() -> None:
    """Connect device, run sequencer and record data."""
    with GCSDevice(CONTROLLERNAME) as pidevice:
        pidevice.InterfaceSetupDlg(key='sample')
        print(f'connected: {pidevice.qIDN().strip()}')

        print('prepare device...')
        pitools.startup(pidevice, refmodes=REFERENCING_MODES, controlmodes=CONTROL_MODES)

        print(f'set user level to {USER_LEVEL_ADVANCED}...')
        set_user_level(pidevice, USER_LEVEL_ADVANCED, USER_LEVEL_ADVANCED_PASSWORD)

        print('delete execution plan items, sequences and user-defined links...')
        delete_execution_plan_items(pidevice, SEQUENCER_ID)
        delete_sequences(pidevice, SEQUENCER_ID)
        delete_user_defined_links(pidevice, LINK_ID)

        print('configure sequences for impulse...')
        configure_sequences_for_impulse(pidevice, SEQUENCER_ID, IMPULSE_AMPLITUDE)
        print_sequence_infos(pidevice, SEQUENCER_ID)

        print('Configure execution plan for impulse...')
        configure_execution_plan_for_impulse(
            pidevice, SEQUENCER_ID, AXIS_ID, IMPULSE_DURATION_SERVO_CYCLES, TOTAL_DURATION_SERVO_CYCLES)
        print_execution_plan(pidevice, SEQUENCER_ID)

        print('configure data recorder...')
        recorder = configure_data_recorder(
            pidevice, RECORDER_ID, SEQUENCER_ID, AXIS_ID, LINK_ID, TOTAL_DURATION_SERVO_CYCLES)

        print('start sequencer...')
        start_sequencer(pidevice, SEQUENCER_ID)
        print_data_recorder_data(recorder)

    print('finished')

def print_sequence_infos(pidevice: GCSDevice, sequencer_id: str) -> None:
    sequence_infos = pidevice.qSQE_LIST(sequencer_id)
    print(f'Sequence infos:\n{sequence_infos}')

def print_execution_plan(pidevice: GCSDevice, sequencer_id: str) -> None:
    execution_plan = pidevice.qSQP_ITEM(sequencer_id)
    print(f'Execution plan:\n{execution_plan}')

def set_user_level(pidevice: GCSDevice, user_level: str, password: str) -> None:
    pidevice.UCL(user_level, password)

def delete_execution_plan_items(pidevice: GCSDevice, sequencer_id: str) -> None:
    execution_plan = pidevice.qSQP_ITEM(sequencer_id)
    for item in execution_plan[0]['Output Items']:
        pidevice.SQP_DEL(sequencer_id, item['Output ID'], int(item['Plan Item Index']))

def delete_sequences(pidevice: GCSDevice, sequencer_id: str) -> None:
    sequence_infos = pidevice.qSQE_LIST(sequencer_id)
    sequence_set_ids = []
    for item in sequence_infos[0]['Sequences']:
        sequence_set_ids.append(int(item['Sequence ID'].split(',')[0]))
    sequence_set_ids = set(sequence_set_ids)
    for sequence_set_id in sequence_set_ids:
        pidevice.SQE_DEL(sequencer_id, sequence_set_id)

def delete_user_defined_links(pidevice: GCSDevice, link_id: str) -> None:
    link_infos = pidevice.qLNK_USER(link_id)
    for item in link_infos[0]['Connections']:
        pidevice.LNK_UDEL(link_id, item['Index'])

def print_data_recorder_data(recorder: datarectools.Datarecorder) -> None:
    print('\t'.join((recorder.header[f'NAME{trace}'] for trace in range(NO_OF_TRACES))))
    for row in range(len(recorder.data[0])):
        print('\t'.join((str(recorder.data[trace][row]) for trace in range(NO_OF_TRACES))))

def configure_sequences_for_impulse(
        pidevice: GCSDevice,
        sequencer_id: str,
        amplitude: float) -> None:
    pidevice.SQE_NEW(sequencer_id, SEQUENCE_ID_IMPULSE_HIGH.sequence_set_id, ONE_VALUE, DATA_TYPE_FLOAT)
    pidevice.SQE_NEW(sequencer_id, SEQUENCE_ID_IMPULSE_LOW.sequence_set_id, ONE_VALUE, DATA_TYPE_FLOAT)
    pidevice.SQE_NEW(sequencer_id, SEQUENCE_ID_TRIGGER_HIGH.sequence_set_id, ONE_VALUE, DATA_TYPE_BOOL)
    pidevice.SQE_NEW(sequencer_id, SEQUENCE_ID_TRIGGER_LOW.sequence_set_id, ONE_VALUE, DATA_TYPE_BOOL)

    pidevice.SQE_VALUE(sequencer_id, str(SEQUENCE_ID_IMPULSE_HIGH), ONE_VALUE, VALUE_INDEX_1, [amplitude])
    pidevice.SQE_VALUE(sequencer_id, str(SEQUENCE_ID_IMPULSE_LOW), ONE_VALUE, VALUE_INDEX_1, [0.0])
    pidevice.SQE_VALUE(sequencer_id, str(SEQUENCE_ID_TRIGGER_HIGH), ONE_VALUE, VALUE_INDEX_1, [PI_TRUE])
    pidevice.SQE_VALUE(sequencer_id, str(SEQUENCE_ID_TRIGGER_LOW), ONE_VALUE, VALUE_INDEX_1, [PI_FALSE])

def configure_execution_plan_for_impulse(
        pidevice: GCSDevice,
        sequencer_id: str,
        axis_id: str,
        impulse_duration: int,
        total_duration: int) -> None:
    pidevice.SQP_ITEM(
        sequencer_id,
        get_float_output_parameter_id(axis_id),
        PLAN_ITEM_INDEX_1,
        str(SEQUENCE_ID_IMPULSE_HIGH),
        SERVO_CYCLE_INDEX_1,
        SUPPORTING_POINT_DISTANCE_1,
        impulse_duration)
    pidevice.SQP_ITEM(
        sequencer_id,
        get_float_output_parameter_id(axis_id),
        PLAN_ITEM_INDEX_2,
        str(SEQUENCE_ID_IMPULSE_LOW),
        SERVO_CYCLE_INDEX_1 + impulse_duration,
        SUPPORTING_POINT_DISTANCE_1,
        total_duration - impulse_duration)
    pidevice.SQP_ITEM(
        sequencer_id,
        get_bool_output_parameter_id(axis_id),
        PLAN_ITEM_INDEX_1,
        str(SEQUENCE_ID_TRIGGER_HIGH),
        SERVO_CYCLE_INDEX_1,
        SUPPORTING_POINT_DISTANCE_1,
        SINGLE_EXECUTION)
    pidevice.SQP_ITEM(
        sequencer_id,
        get_bool_output_parameter_id(axis_id),
        PLAN_ITEM_INDEX_2,
        str(SEQUENCE_ID_TRIGGER_LOW),
        SERVO_CYCLE_INDEX_2,
        SUPPORTING_POINT_DISTANCE_1,
        total_duration - 1)

def configure_data_recorder(
        pidevice: GCSDevice,
        recorder_id: str,
        sequencer_id: str,
        axis_id: str,
        link_id: str,
        number_of_values: int) -> datarectools.Datarecorder:
    float_output_resource_id = get_float_output_resource_id(sequencer_id, axis_id)
    bool_output_resource_id = get_bool_output_resource_id(sequencer_id, axis_id)
    target_position_resource_id = get_target_position_resource_id(axis_id)
    current_position_resource_id = get_current_position_resource_id(axis_id)
    trigger_signal_resource_id = get_trigger_signal_resource_id(recorder_id)

    recorder = datarectools.Datarecorder(pidevice, recorder_id)
    recorder.number_of_values = number_of_values
    recorder.record_rate = RECORDING_RATE
    recorder.traces = {TRACE_ID_1: float_output_resource_id,
                       TRACE_ID_2: bool_output_resource_id,
                       TRACE_ID_3: target_position_resource_id,
                       TRACE_ID_4: current_position_resource_id}
    recorder.trigger = [TRIGGER_MODE_SIGNAL, '', '']

    pidevice.LNK_USER(link_id,
                      LINK_INDEX_1,
                      bool_output_resource_id[0],
                      bool_output_resource_id[1],
                      bool_output_resource_id[2],
                      trigger_signal_resource_id[0],
                      trigger_signal_resource_id[1],
                      trigger_signal_resource_id[2])

    recorder.arm()

    return recorder

def start_sequencer(pidevice: GCSDevice, sequencer_id: str) -> None:
    pidevice.SQC_START(sequencer_id)

def get_float_output_parameter_id(axis_id: str) -> str:
    return f'0x110,{axis_id.split('_')[1]}'

def get_bool_output_parameter_id(axis_id: str) -> str:
    return f'0x111,{axis_id.split('_')[1]}'

def get_float_output_resource_id(sequencer_id: str, axis_id: str) -> list[str]:
    return [sequencer_id, NO_FUNCTION_UNIT, get_float_output_parameter_id(axis_id)]

def get_bool_output_resource_id(sequencer_id: str, axis_id: str) -> list[str]:
    return [sequencer_id, NO_FUNCTION_UNIT, get_bool_output_parameter_id(axis_id)]

def get_target_position_resource_id(axis_id: str) -> list[str]:
    return [f'CSTR_{axis_id.split('_')[1]}', NO_FUNCTION_UNIT, '0x101,1']

def get_current_position_resource_id(axis_id: str) -> list[str]:
    return [f'CSTR_{axis_id.split('_')[1]}', NO_FUNCTION_UNIT, '0x103']

def get_trigger_signal_resource_id(recorder_id: str) -> list[str]:
    return [recorder_id, NO_FUNCTION_UNIT, '0x107']

if __name__ == '__main__':
    # import logging
    # logging.basicConfig(level=logging.DEBUG)
    main()
